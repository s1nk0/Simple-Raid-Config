export declare enum WindDirection {
    EAST = 1,
    NORTH = 2,
    WEST = 3,
    SOUTH = 4,
    SE = 5,
    SW = 6,
    NW = 7,
    NE = 8
}
