export declare enum BotAmount {
    AS_ONLINE = "AsOnline",
    LOW = "Low",
    MEDIUM = "Medium",
    HIGH = "High",
    HORDE = "Horde"
}
