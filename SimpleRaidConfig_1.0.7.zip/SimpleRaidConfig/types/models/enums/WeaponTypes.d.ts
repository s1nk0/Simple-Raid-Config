export declare enum Weapons127x55 {
    ASH_12 = "5cadfbf7ae92152ac412eeef"
}
export declare enum Weapons86x70 {
    MK_18 = "5fc22d7c187fea44d52eda44",
    AXMC = "627e14b21713922ded6f2c15"
}
export declare enum Weapons9x39 {
    AS_VAL = "57c44b372459772d2b39b8ce",
    VSS_VINTOREZ = "57838ad32459774a17445cd2"
}
export declare enum Weapons762x54R {
    SVDS = "5c46fbd72e2216398b5a8c9c",
    MP_18 = "61f7c9e189e6fb1a5e3ea78d",
    MOSIN_INFANTRY = "5bfd297f0db834001a669119",
    MOSIN_SNIPER = "5ae08f0a5acfc408fb1398a1",
    SV_98 = "55801eed4bdc2d89578b4588"
}
export declare enum Weapons762x51 {
    VPO_101 = "5c501a4d2e221602b412b540",
    DT_MDR_762 = "5dcbd56fdbd3d91b3e5468d5",
    SA_58 = "5b0bbe4e5acfc40dc528a72d",
    SCARH_BLACK = "6183afd850224f204c1da514",
    SCARH_FDE = "6165ac306ef05c2ce828ef74",
    HK_G28 = "6176aca650224f204c1da3fb",
    M1A = "5aafa857e5b5b00018480968",
    RFB = "5f2a9575926fd9352339381f",
    RSASS = "5a367e5dc4a282000e49738f",
    SR_25 = "5df8ce05b11454561e39243b",
    DVL_10 = "588892092459774ac91d4b11",
    M700 = "5bfea6e90db834001b7347f3",
    T5000M = "5df24cf80dee1b22f862e9bc"
}
export declare enum Weapons366TKM {
    VPO_209 = "59e6687d86f77411d949b251",
    VPO_215 = "5de652c31b7e3716273428be"
}
export declare enum Weapons762x39 {
    OP_SKS = "587e02ff24597743df3deaeb",
    SKS = "574d967124597745970e7c94",
    AK_103 = "5ac66d2e5acfc43b321d4b53",
    AK_104 = "5ac66d725acfc43b321d4b60",
    AKM = "59d6088586f774275f37482f",
    AKMN = "5a0ec13bfcdbcb00165aa685",
    AKMS = "59ff346386f77477562ff5e2",
    AKMSN = "5abcbc27d8ce8700182eceeb",
    MK47_MUTANT = "606587252535c57a13424cfd",
    RD_704 = "628a60ae6b1d481ff772e9c8",
    VPO_136 = "59e6152586f77473dc057aa1"
}
export declare enum Weapons762x35 {
    MCX = "5fbcc1d9016cce60e8341ab3"
}
export declare enum Weapons556x45 {
    ADAR_2_15 = "5c07c60e0db834002330051f",
    AK_101 = "5ac66cb05acfc40198510a10",
    AK_102 = "5ac66d015acfc400180ae6e4",
    DT_MDR_556 = "5c488a752e221602b412af63",
    HK_416A5 = "5bb2475ed4351e00853264e3",
    HK_G36 = "623063e994fc3f7b302a9696",
    M4A1 = "5447a9cd4bdc2dbd208b4567",
    SCARL_BLACK = "6184055050224f204c1da540",
    SCARL_FDE = "618428466ef05c2ce828f218",
    TX15_DML = "5d43021ca4b9362eab4b5e25"
}
export declare enum Weapons545x39 {
    AK_105 = "5ac66d9b5acfc4001633997a",
    AK_74 = "5bf3e03b0db834001d2c4a9c",
    AK_74M = "5ac4cd105acfc40016339859",
    AK_74N = "5644bd2b4bdc2d3b4c8b4572",
    AKS_74 = "5bf3e0490db83400196199af",
    AKS_74N = "5ab8e9fcd8ce870019439434",
    AKS_74U = "57dc2fa62459775949412633",
    AKS_74UB = "5839a40f24597726f856b511",
    AKS_74UN = "583990e32459771419544dd2",
    SAG_AK = "628b5638ad252a16da6dd245",
    SAG_AK_SHORT = "628b9c37a733087d0d7fe84b",
    RPK_16 = "5beed0f50db834001c062b12"
}
export declare enum Weapons57x28FN {
    FN_57_BLACK = "5d3eb3b0a4b93615055e84d2",
    FN_57_FDE = "5d67abc1a4b93614ec50137f",
    FN_P90 = "5cc82d76e24e8d00134b4b83"
}
export declare enum Weapons46x30HK {
    MP7A1 = "5ba26383d4351e00334c93d9",
    MP7A2 = "5bd70322209c4d00d7167b8f"
}
export declare enum Weapons1143x23 {
    M1911A1 = "5e81c3cbac2bb513793cdc75",
    M45A1 = "5f36a0e5fbf956000b716b65",
    USP45 = "6193a720f8ee7e52e42109ed",
    UMP45 = "5fc3e272f8b6a877a729eac5",
    VECTOR45 = "5fb64bc92b1b027b1f50bcf2"
}
export declare enum Weapons9x33R {
    CR_50DS = "61a4c8884f95bc3b2c5dc96f"
}
export declare enum Weapons9x21 {
    SR_1MP = "59f98b4986f7746f546d2cef"
}
export declare enum Weapons9x19 {
    GLOCK_17 = "5a7ae0c351dfba0017554310",
    GLOCK_18C = "5b1fa9b25acfc40018633c01",
    M9A3 = "5cadc190ae921500103bb3b6",
    MP_443 = "576a581d2459771e7b1bc4f1",
    P226R = "56d59856d2720bd8418b456a",
    PL_15 = "602a9740da11d6478d5a06dc",
    CR_200DS = "624c2e8614da335f1e034d8c",
    MP5 = "5926bb2186f7744b1c6c6e60",
    MP5K = "5d2f0d8048f0356c925bc3b0",
    MP9 = "5e00903ae9dc277128008b87",
    MP9_N = "5de7bd7bfd6b4e6e2276dc25",
    MPX = "58948c8e86f77409493f7266",
    PP_19_01 = "59984ab886f7743e98271174",
    SAIGA_9 = "59f9cabd86f7743a10721f46",
    STM_9 = "60339954d62c9b14ed777c06",
    VECTOR_9MM = "5fc3f2d5900b1d5091531e57"
}
export declare enum Weapons9x18 {
    APB = "5abccb7dd8ce87001773e277",
    APS = "5a17f98cfcdbcb0980087290",
    PB_SILENCED = "56e0598dd2720bb5668b45a6",
    PM = "5448bd6b4bdc2dfc2f8b4569",
    PM_T = "579204f224597773d619e051",
    PP9_KLIN = "57f4c844245977379d5c14d1",
    PP91_KEDR = "57d14d2524597714373db789",
    PP91_KEDRB = "57f3c6bd24597738e730fa2f"
}
export declare enum Weapons762x25 {
    TT = "571a12c42459771f627b58a0",
    TT_GOLD = "5b3b713c5acfc4330140bd8d",
    PPSH_41 = "5ea03f7400685063ec28bfa8"
}
export declare enum Weapons12Gauge {
    M3_SUPER90 = "6259b864ebedf17603599e88",
    M590A1 = "5e870397991fd70db46995c8",
    M870 = "5a7828548dc32e5a9c28b516",
    MP_133 = "54491c4f4bdc2db1078b4568",
    MP_153 = "56dee2bdd2720bc8328b4567",
    MP_155 = "606dae0ab0e443224b421bb7",
    MP_43_1C = "5580223e4bdc2d1c128b457f",
    MTS_255_12 = "60db29ce99594040e04c4a27",
    SAIGA_12GA = "576165642459773c7a400233"
}
export declare enum Weapons20Gauge {
    TOZ_106 = "5a38e6bac4a2826c6e06d79b"
}
export declare enum Weapons23x75 {
    KS_23M = "5e848cc2988a8701445df1e8"
}
