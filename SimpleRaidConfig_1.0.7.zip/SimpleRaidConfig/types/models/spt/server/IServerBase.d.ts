export interface IServerBase {
    ip: string;
    port: number;
}
