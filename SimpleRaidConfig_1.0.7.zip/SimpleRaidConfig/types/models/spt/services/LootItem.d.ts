export declare class LootItem {
    id?: string;
    tpl: string;
    isPreset: boolean;
    stackCount: number;
}
