export interface IPMCLootGenerator {
    generatePMCPocketLootPool(): string[];
    generatePMCBackpackLootPool(): string[];
}
