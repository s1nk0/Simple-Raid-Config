export interface IRepeatableQuestChangeRequest {
    Action: "RepeatableQuestChange";
    qid: string;
}
