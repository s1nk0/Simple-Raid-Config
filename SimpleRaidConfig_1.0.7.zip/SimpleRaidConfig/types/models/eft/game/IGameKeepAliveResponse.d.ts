export interface IGameKeepAliveResponse {
    msg: string;
    utc_time: number;
}
