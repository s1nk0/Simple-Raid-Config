export interface ISelectProfileRequestData {
    uid: string;
}
