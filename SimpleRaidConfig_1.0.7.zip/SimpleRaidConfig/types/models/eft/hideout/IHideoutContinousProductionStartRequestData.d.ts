export interface IHideoutContinousProductionStartRequestData {
    Action: "HideoutContinuousProductionStart";
    recipeId: string;
    timestamp: number;
}
