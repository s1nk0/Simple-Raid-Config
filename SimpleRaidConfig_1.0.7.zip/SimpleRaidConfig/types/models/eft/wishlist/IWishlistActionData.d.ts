export interface IWishlistActionData {
    Action: string;
    templateId: string;
}
