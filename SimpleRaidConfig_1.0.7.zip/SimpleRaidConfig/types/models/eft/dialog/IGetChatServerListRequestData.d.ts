export interface IGetChatServerListRequestData {
    VersionId: string;
}
