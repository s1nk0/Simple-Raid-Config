export declare class OnLoad {
    onLoad(): Promise<void>;
    getRoute(): string;
}
