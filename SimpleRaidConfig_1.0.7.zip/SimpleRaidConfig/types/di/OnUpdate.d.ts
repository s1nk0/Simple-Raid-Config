export declare class OnUpdate {
    onUpdate(timeSinceLastRun: number): Promise<boolean>;
    getRoute(): string;
}
