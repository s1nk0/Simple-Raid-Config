export declare enum HttpMethods {
    OPTIONS = "OPTIONS",
    GET = "GET",
    POST = "POST",
    PUT = "PUT",
    PATCH = "PATCH",
    DELETE = "DELETE"
}
