Values
======
Ai amount:
----------
AsOnline
None
Low
Medium
High
Horde

Ai Diff:
--------
AsOnline
Easy
Medium
Hard
Impossible
Random